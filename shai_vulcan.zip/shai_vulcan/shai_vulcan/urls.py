"""shai_vulcan URL Configuration

"""
from rest_framework.routers import DefaultRouter
from rest_framework_extensions.routers import NestedRouterMixin
from shai_vulcan_api import views
from django.contrib import admin
from django.urls import path, include


class NestedDefaultRouter(NestedRouterMixin, DefaultRouter):
    pass


router = NestedDefaultRouter()


# Add this for getting all the details of a specific pluginID
PluginID_router = router.register('vulners', views.VulnersViewSet)
PluginID_router.register(
    'pluginId', views.VulnersViewSet,
    basename='specific-PluginID',
    parents_query_lookups=['PluginID']
)

#this is for getting a specific data by cve
CveList_router = router.register('vulners', views.SpecificCVEViewSet)
CveList_router.register(
    'cvelist',views.SpecificCVEViewSet,
    basename='specific-CVE',
    parents_query_lookups=['PluginID','published','title','score']
)


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include(router.urls))
]