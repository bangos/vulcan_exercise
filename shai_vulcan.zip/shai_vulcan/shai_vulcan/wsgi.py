"""
WSGI config for shai_vulcan project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/3.0/howto/deployment/wsgi/
"""


import os
import shai_vulcan.startup as startup
from django.core.wsgi import get_wsgi_application

startup.run()

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'shai_vulcan.settings')

application = get_wsgi_application()
