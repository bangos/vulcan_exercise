""""
This module is for setup the data download the json file
and insert to db
"""

import vulners
from shai_vulcan_api.models import Vulners


def download_and_insert_json():
    api_key = "452T91PRNXBP06VJUMERYZCI108WX9UCKDI9Z8M5FPSFE373VODZJN32LBMRLL0L"  # get key from log in that I made
    vapi = vulners.Vulners(api_key=api_key)
    data = vapi.archive("nessus")

    # pars the date in json format
    for item in data:
        source = item.get("_source")
        if source is None:
            continue
        pubid = source.get("pluginID")
        pub = source.get("published")
        tit = source.get("title")
        score = get_score(source.get("cvss"))
        cvel = source.get("cvelist")
        insert_row(pubid,pub,tit,score,cvel)

#get the score from cvss
def get_score(cvss):
    return None if cvss is None else cvss.get("score")


# insert to the database
def insert_row(id,publihed,title,score,cvelist):
    vulnerstable = Vulners(PluginID=id, published=publihed, title=title,score=score,cvelist=cvelist)
    vulnerstable.save()
    vulnerstable.id


def run():
    download_and_insert_json()

