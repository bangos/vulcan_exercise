from rest_framework import viewsets
from rest_framework_extensions.mixins import NestedViewSetMixin
from .serializers import VulnersSerializer
from .models import Vulners


class VulnersViewSet(NestedViewSetMixin,viewsets.ModelViewSet):
    queryset = Vulners.objects.all().order_by('PluginID','published','score')
    serializer_class = VulnersSerializer


class SpecificCVEViewSet(NestedViewSetMixin,viewsets.ModelViewSet):
    queryset = Vulners.objects.filter(cvelist__icontains='specific-CVE')
    serializer_class = VulnersSerializer
