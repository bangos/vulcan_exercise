from django.apps import AppConfig


class ShaiVulcanChallengeConfig(AppConfig):
    name = 'shai_vulcan_api'
