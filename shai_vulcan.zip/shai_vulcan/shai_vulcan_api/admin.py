from django.contrib import admin
from .models import Vulners

admin.site.register(Vulners)