from rest_framework import serializers
from .models import Vulners


class VulnersSerializer(serializers.HyperlinkedModelSerializer):
    PluginID = serializers.IntegerField()
    published = serializers.DateTimeField()
    title = serializers.CharField(max_length=100)
    score = serializers.FloatField()
    cvelist = serializers.CharField(max_length=100) # as I said in the models

    class Meta:
        model = Vulners
        fields = '__all__'