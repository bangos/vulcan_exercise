from django.db import models


# Create your models here.
class Vulners(models.Model):
    PluginID = models.IntegerField(null=True)
    published = models.DateTimeField(null=True)
    title = models.CharField(max_length=100,null=True)
    score = models.FloatField(null=True)
    cvelist = models.CharField(max_length=100,null=True) #I know there must be a better way(if I had to it now I wuld use mysql and arrayList)

    def __int__(self):
        return self.PluginID

